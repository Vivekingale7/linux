/*Program for Printing 
Hello World*/

using namespace std;
#include<iostream>
int main() 
{
 cout<<"Hello World"<<endl;                   	//It will Display Hello World.
 cout<<"Welcome to IT  Department !!\n";	//It will Display Welcome to IT Department !!
 return 0;
}

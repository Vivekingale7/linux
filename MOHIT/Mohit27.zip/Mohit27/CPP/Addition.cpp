using namespace std;
#include<iostream>
int main()
{
 int a=10,b=20,c;       				
 c = a + b;
 cout<<"Addition of "<<a<<" & "<<b<<" is : "<<c<<endl;
 return 0;
}

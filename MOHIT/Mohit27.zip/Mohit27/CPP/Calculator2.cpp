using namespace std;
#include<iostream>
int main()
{
 int  a,b,c,d,e,f;
 cout<<"Enter First Number : ";
 cin>>a;
 cout<<"Enter Second Number : ";
 cin>>b;      				
 c = a + b;
 d = a - b;
 e = a * b;
 f = a / b;
 cout<<"Addition of "<<a<<" & "<<b<<" is : "<<c<<endl;
 cout<<"Subtraction of "<<a<<" & "<<b<<" is : "<<d<<endl;
 cout<<"Multiplication of "<<a<<" & "<<b<<" is : "<<e<<endl;
 cout<<"Division of "<<a<<" & "<<b<<" is : "<<f<<endl;
 return 0;
}

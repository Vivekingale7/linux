public class Circle
{
 public static void main(String args[])
 {
  double r = 10 , c;
  double pi = 3.14;
  c = pi * r * r;
  System.out.println("Area of Circle is : "+c);
 }
}

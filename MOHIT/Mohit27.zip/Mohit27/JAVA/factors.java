public class factors
{
 public static void main(String args[])
 {
  int a = 20, i = 1 ;
  for(a>i)
  {
  if( a % i == 0 )
   {
   System.out.println("factors of " +a " is : "+i);
   }
  }
 }
}

public class Square
{
 public static void main(String args[])
 {
  int a = 10 , c;
  c =a*a;
  System.out.println("Area of Square is : "+c);
 }
}

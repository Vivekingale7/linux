public class Calculator
{
 public static void main(String args[])
 {
  int a = 10 , b = 10 , c , d , e ;
  float f;
  c = a + b;
  d = a - b;
  e = a * b;
  f = a / b;
  System.out.println("Addition is : "+c);
  System.out.println("Subtraction is : "+d);
  System.out.println("Multiplication is : "+e);
  System.out.println("Division is : "+f);
 }
}

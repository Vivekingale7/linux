class Hello {
    public static void main(String args[]) {
         System.out.println("Hello");
	 System.out.println("Name : Mohit");
	 System.out.println("Reoll no. = 27");
   }
}

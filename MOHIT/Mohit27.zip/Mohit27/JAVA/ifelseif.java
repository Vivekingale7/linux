public class ifelseif
{
 public static void main(String args[])
 {
  int a = 10 , b =15 ;
  if(a > b)
  {
  System.out.println(+a+" is Greater than "+b);
  }else
  {
   System.out.println(+b+" is Greater than "+a);
  }
 }
}

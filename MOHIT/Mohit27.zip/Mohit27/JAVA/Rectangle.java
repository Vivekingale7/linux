public class Rectangle
{
 public static void main(String args[])
 {
  int a = 10 , b =15 , c;
  c =2*(a + b);
  System.out.println("Area of Rectangle is : "+c);
 }
}

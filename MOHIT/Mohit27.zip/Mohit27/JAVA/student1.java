class student1 
{
    public static void main(String args[]) {
        int id = 1 ;
        String name = "Name" ;  
 }
}
 class Test
{
     student1  s1 = new student1();
     System.out.println(s1.id);
     System.out.println(s1.name);
  }

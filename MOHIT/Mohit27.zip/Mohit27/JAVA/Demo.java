public class Demo
{
 public static void main(String args[])
 {
  int a = 10 , b =15 , c;
  System.out.println("Hello");
  c = a + b;
  System.out.println("Addition is : "+c);
 }
}

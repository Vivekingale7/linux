class student {
        int id = 1 ;
        String name = "Name" ;
    public static void main(String args[]) {
   student s1 = new student() ;
   System.out.println(s1.id) ;
   System.out.println(s1.name) ;
  }
}
